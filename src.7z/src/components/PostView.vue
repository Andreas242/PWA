<template>
  <div class="waiting">
    <div>
      <video id="videoplayer" autoplay></video>
    </div>
    <canvas id="canvas" width="320px" height="240px"></canvas>
    <div class="capture-button">
      <button @click="takePicture()" id="captureButton">Take photo</button>
    </div>
    <input type="text"  required v-model="name"/>
    {{name}}
    <input type="number" required v-model="score"/>
    {{score}}
    <button @click="registerPlayer()">Ok, lets play!</button>
  </div>
</template>
<script>
function initializeMedia () {
  setTimeout(function () {
    const canvasElement = document.querySelector('#canvas')
    const captureButton = document.querySelector('#captureButton')
    const videoPlayer = document.querySelector('#videoplayer')
    videoPlayer.style.display = 'block'
    canvasElement.style.display = 'none'
    captureButton.style.display = 'block'
    navigator.mediaDevices.getUserMedia({video: true}).then(function (stream) {
      videoPlayer.srcObject = stream
      console.log(videoPlayer)
    }).catch(function (err) {
      alert(err)
    })
  }, 400)
}
export default {
  data () {
    return {
      'catUrl': null,
      'name': null,
      'score': null,
      'newPostKey': null,
      'newUserKey': null,
      'canvas': document.querySelector('#canvas')
    }
  },
  methods: {
    takePicture () {
      const canvasElement = document.querySelector('#canvas')
      const captureButton = document.querySelector('#captureButton')
      const videoPlayer = document.querySelector('#videoplayer')
      canvasElement.style.display = 'block'
      videoPlayer.style.display = 'none'
      captureButton.style.display = 'none'
      var context = canvasElement.getContext('2d')
      context.drawImage(videoPlayer, 0, 0, canvasElement.width, videoPlayer.videoHeight / (videoPlayer.videoWidth / canvasElement.width))
      videoPlayer.srcObject.getVideoTracks().forEach(function (track) {
        track.stop()
      })
    },
    registerPlayer () {
      if (!localStorage.id) {
        const canvasElement = document.querySelector('#canvas')
        this.newPostKey = this.$root.$firebaseRefs.players.push()
        localStorage.id = this.newPostKey.key
        localStorage.name = this.name
        this.newPostKey.set({
          id: this.newPostKey.key,
          name: this.name,
          color: 'green',
          image: canvasElement.toDataURL(),
          score: 1000
        }).then(this.$router.push('/'))
      } else {
        alert('NOOO')
      }
    }
  },
  created () {
    initializeMedia()
  }
}
</script>

<style scoped>
  .waiting {
    padding: 10px;
    color: #555;
  }
  #videoplayer {
    width: 15rem;
    height: 100%;
    margin: auto;
    border-radius: 2rem;
  }
  .capture-button {
    margin-top: 3rem;
  }
  #canvas {
    display: none;
    width: 15rem;
    height: 100%;
    margin: auto;
    border-radius: 2rem;
  }
</style>
