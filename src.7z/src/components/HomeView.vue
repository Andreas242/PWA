<template>
  <div class="basic-setup">
    <div v-if="showWelcome" class="presentation__wrapper">
    <div class="svg" id="svg">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="svg" x="0px" y="0px" width="150px" height="150px" viewBox="0 0 213.235 241.176" enable-background="new 0 0 213.235 241.176" xml:space="preserve" fill="#0057B8">
        <path d="M108.581,64.968V14.124l44.007,25.422L108.581,64.968"/>
        <path fill-opacity="0.9" d="M153.591,92.101V41.258L109.582,66.68L153.591,92.101"/><path d="M155.586,92.062V41.221l44.009,25.42L155.586,92.062"/><path fill-opacity="0.7" d="M200.299,119.14V68.297l-44.004,25.421L200.299,119.14"/><path fill-opacity="0.85" d="M155.586,146.255V95.412l44.009,25.422L155.586,146.255"/><path fill-opacity="0.7" d="M200.299,173.35v-50.844l-44.004,25.422L200.299,173.35"/><path fill-opacity="0.6" d="M155.586,200.482v-50.84l44.009,25.417L155.586,200.482"/><path fill-opacity="0.5" d="M153.591,200.521v-50.84l-44.009,25.418L153.591,200.521"/><path fill-opacity="0.6" d="M108.581,227.696v-50.844l44.007,25.421L108.581,227.696"/><path fill-opacity="0.5" d="M106.62,227.696v-50.844l-44.005,25.421L106.62,227.696"/><path fill-opacity="0.7" d="M61.562,200.553V149.71l44.007,25.423L61.562,200.553"/><path fill-opacity="0.7" d="M59.709,200.56v-50.843l-44.008,25.422L59.709,200.56"/><path fill-opacity="0.7" d="M14.699,173.467v-50.843l44.01,25.42L14.699,173.467"/><path fill-opacity="0.5" d="M59.709,146.235V95.392l-44.008,25.42L59.709,146.235"/><path fill-opacity="0.7" d="M14.699,119.141V68.297l44.01,25.421L14.699,119.141"/><path fill-opacity="0.6" d="M59.709,92.101V41.258L15.701,66.68L59.709,92.101"/><path fill-opacity="0.85" d="M61.562,92.092V41.249l44.007,25.419L61.562,92.092"/>
        <path fill-opacity="0.9" d="M106.62,64.968V14.124L62.614,39.546L106.62,64.968"/>
      </svg>
    </div>
    <div id="name">
    <div v-if="name">
    <div class="name">
      Velkommen {{ name }}!
    </div>
    </div>
    <div v-else>
      Velkommen
    </div>
    </div>
  </div>
  <div class="players">
    <transition-group name="list" tag="div" class="score" keep-alive>
    <div v-for="player in this.$root.players" :key="player.name" v-bind:key="player" class="image-card" @click="">
      <div v-if="player.score && player.score < 900" class="player__card">
        <figure class="player__shape">
          <div v-if="player.image">
            <img v-bind:src="player.image" class="player-image"/>
          </div>
        </figure>
        <div class="player__info">
        <h3>{{ player.name }}</h3>
        <div>{{ player.message }} </div>
        <div>{{ player.score }}</div>
      </div>
      </div>
      </div>
  </transition-group>
  </div>
</div>
</template>

<script>
export default {
  data () {
    return {
      myDev: localStorage.id,
      name: localStorage.name || '',
      showWelcome: true
    }
  }
}
</script>
<style scoped>
  .list {
    width: 100%;
    padding: 0;
  }
  .list-enter-active, .list-leave-active {
    transition: all 1s;
  }
  .list-enter, .list-leave-to /* .list-leave-active below version 2.1.8 */ {
    opacity: 0;
    transform: translateY(30px);
  }

  .image-card:first-child .player__card{
    background-color: #DDD;
    margin: 3rem 0;
    box-shadow: 0.2rem 1rem 2rem;
    border-radius: 3rem;
    padding: 1rem;
    width: 100%;
    float: left;
  }

  .player__card{
    background-color: #DDD;
    margin: 3rem 0;
    box-shadow: 0.2rem 1rem 2rem;
    border-radius: 1rem;
    padding: 0.5rem;
    width: 12rem;
    margin-right: 1rem;
    float: left;
  }

  .player-image {
    transform: translateX(-25%);
    width: 135%;
  }

  .player__shape {
    height: 7rem;
    width: 7rem;
    background-color: orangered;
    float: left;
    shape-outside: circle(50% at 50% 50%);
    clip-path: circle(50% at 50% 50%);
  }

  .player__img {
    height: 7rem;
  }
  .players {
    margin: auto;
    width: 80%
  }
  .white {
    color: #fff;
  }

.svg {
  display: inline-block;
  width: 200px;
  line-height: 200px;
  text-align: center;
  background-color: #FFF;
  border-radius: 50%;
  margin-top: 30vh;
}

#svg {
  display: inline-block;
  vertical-align: middle;
  fill: #0057B8;
  transition: all 2s;

}

.basic-setup {
  background-color: #0057B8;
}

#name {
    color: white;
    transition: all 2s;
    margin-top: 50px;
    height: 100px;
    text-shadow: 1px 3px 10px rgba(0,0,0,0.5);
    text-transform: uppercase;
    font-size: 2.5rem;
    line-height: 2.5rem;
}

#svg path:nth-child(1) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.1s;
          animation-delay: 0.1s;
          animation-iteration-count: 1;
}
#svg path:nth-child(1):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(2) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.2s;
          animation-delay: 0.2s;
          animation-iteration-count: 1;
}
#svg path:nth-child(2):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(3) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.3s;
          animation-delay: 0.3s;
          animation-iteration-count: 1;
}
#svg path:nth-child(3):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(4) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.4s;
          animation-delay: 0.4s;
          animation-iteration-count: 2;
}
#svg path:nth-child(4):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(5) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.5s;
          animation-delay: 0.5s;
          animation-iteration-count: 2;
}
#svg path:nth-child(5):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(6) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.6s;
          animation-delay: 0.6s;
          animation-iteration-count: 2;
}
#svg path:nth-child(6):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(7) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.7s;
          animation-delay: 0.7s;
          animation-iteration-count: 2;
}
#svg path:nth-child(7):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(8) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.8s;
          animation-delay: 0.8s;
          animation-iteration-count: 2;
}
#svg path:nth-child(8):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(9) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 0.9s;
          animation-delay: 0.9s;
          animation-iteration-count: 3;
}
#svg path:nth-child(9):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(10) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1s;
          animation-delay: 1s;
          animation-iteration-count: 3;
}
#svg path:nth-child(10):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(11) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.1s;
          animation-delay: 1.1s;
          animation-iteration-count: 3;
}
#svg path:nth-child(11):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(12) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.2s;
          animation-delay: 1.2s;
          animation-iteration-count: 4;
}
#svg path:nth-child(12):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(13) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.3s;
          animation-delay: 1.3s;
          animation-iteration-count: 4;
}
#svg path:nth-child(13):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(14) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.4s;
          animation-delay: 1.4s;
          animation-iteration-count: 4;
}
#svg path:nth-child(14):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(15) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.5s;
          animation-delay: 1.5s;
          animation-iteration-count: 4;
}
#svg path:nth-child(15):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(16) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.6s;
          animation-delay: 1.6s;
          animation-iteration-count: 4;
}
#svg path:nth-child(16):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}
#svg path:nth-child(17) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.7s;
          animation-delay: 1.7s;
          animation-iteration-count: 4;
}
#svg path:nth-child(17):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}

#svg path:nth-child(18) {
  -webkit-animation: pweek 1.8s linear infinite;
          animation: pweek 1.8s linear infinite;
  -webkit-animation-delay: 1.8s;
          animation-delay: 1.8s;
          animation-iteration-count: 4;
}
#svg path:nth-child(18):hover {
  -webkit-animation-play-state: paused;
          animation-play-state: paused;
}

@-webkit-keyframes pweek {
  0% {
    fill: #0057B8;
  }
  20% {
    fill: #F11E4A;
  }
  40% {
    fill: #F8A527;
  }
  60% {
    fill: #266D7F;
  }
  80% {
    fill: #82A;
  }
  100% {
    fill: #0057B8;
  }
}

@keyframes pweek {
  0% {
    fill: #0057B8;
  }
  20% {
    fill: #F11E4A;
  }
  40% {
    fill: #F8A527;
  }
  60% {
    fill: #266D7F;
  }
  80% {
    fill: #82A;
  }
  100% {
    fill: #0057B8;
  }
}

.hide {
    opacity: 0 !important;
    transform: translateY(-20px);
}

.hideName {
  opacity: 0 !important;
  transform: translateY(20px);
}

.gone {
   display: none !important;
}

.name.showName {
    opacity: 1;
  }

#svg.showSVG {
    opacity: 1;
}

.presentation__wrapper {
  opacity: 0;
  height: 0vh;
  animation-name: fadeOut;
  animation-duration: 4s;
}

@keyframes fadeOut {
    0%   {opacity: 1; height: 100vh;}
    75%  {opacity: 1; height: 100vh;}
    100% {opacity: 0; height: 0vh;}
}


</style>
