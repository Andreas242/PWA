<template>
  <div class='form'>
    <div class='play__information'>
      <table class='table table-striped table-bordered'>
        <tr>
          <td>Tilt Left/Right [gamma]</td>
          <td id='doTiltLR'></td>
        </tr>
        <tr>
          <td>Tilt Front/Back [beta]</td>
          <td id='doTiltFB'></td>
        </tr>
        <tr>
          <td>Direction [alpha]</td>
          <td id='doDirection'></td>
        </tr>
        <tr>
          <td id='firstRandom'></td>
        </tr>
        <tr>
          <td id='firstDiff'></td>
        </tr>
        <tr>
          <td id='secondRandom'></td>
        </tr>
        <tr>
          <td id='secondDiff'></td>
        </tr>
      </table>
            <div class='container' id='logoContainer'>
        <img src='https://www.w3.org/html/logo/downloads/HTML5_Badge_512.png' id='imgLogo'>
      </div>
    </div>
    <div class='play__playarea'>

    button changed by canvas or telling degree to hold device
    </div>
    <div class='play__feedback'>
      <button @click="startGame()">Start!</button>
    </div>
  </div>
</template>
<script>

// function deviceOrientationHandler (eventData) {
/*  var tiltLR = eventData.gamma
  var tiltFB = eventData.beta
  var dir = eventData.alpha

  document.getElementById('doTiltLR').innerHTML = Math.round(tiltLR)
  document.getElementById('doTiltFB').innerHTML = Math.round(tiltFB)
  document.getElementById('doDirection').innerHTML = Math.round(dir)

  var logo = document.getElementById('imgLogo')
  logo.style.webkitTransform = 'rotate(' + tiltLR + 'deg) rotate3d(1,0,0, ' + (tiltFB * -1) + 'deg)'
  logo.style.MozTransform = 'rotate(' + tiltLR + 'deg)'
  logo.style.transform = 'rotate(' + tiltLR + 'deg) rotate3d(1,0,0, ' + (tiltFB * -1) + 'deg)'
*/
//  console.log('wait for it!')
// }

export default {
  data () {
    return {
      currentScore: 0,
      firstRandom: 1,
      secondRandom: 1,
      score: 1
    }
  },
  methods: {
    startGame () {
      if ('DeviceOrientationEvent' in window) {
        let that = this
        let mu = setInterval(function () {
          that.score += Math.abs(Math.abs(parseInt(document.getElementById('doTiltLR').innerHTML, 10)) - Math.abs(that.firstRandom)) + Math.abs(Math.abs(parseInt(document.getElementById('doTiltFB').innerHTML, 10)) - Math.abs(that.secondRandom))
          that.firstRandom = Math.floor(Math.random() * 80) - 50
          that.secondRandom = Math.floor(Math.random() * 80) - 50
        }, 5000)
        setTimeout(function () {
          let finalScore = that.score
          clearInterval(mu)
          document.getElementById('secondRandom').innerHTML = finalScore + ' score'
          console.log('clear')
          that.$root.$firebaseRefs.players.child(`${window.localStorage.id}`).update({score: parseInt(finalScore, 10)}).then(that.$router.push('/'))
        }, 20002)
        window.addEventListener('deviceorientation', this.tiltImage, false)
      } else {
        console.log('sorry!')
        alert('nooooo!!!!')
        document.getElementById('logoContainer').innerText = 'Device Orientation API not supported.'
      }
    },
    tiltImage (eventData) {
      let tiltLR = eventData.gamma
      let tiltFB = eventData.beta
      let dir = eventData.alpha
      document.getElementById('doTiltLR').innerHTML = Math.round(tiltLR)
      document.getElementById('doTiltFB').innerHTML = Math.round(tiltFB)
      document.getElementById('doDirection').innerHTML = Math.round(dir)
      document.getElementById('firstRandom').innerHTML = this.score
      let logo = document.getElementById('imgLogo')
      logo.style.webkitTransform = 'rotate(' + (tiltLR + this.firstRandom) + 'deg) rotate3d(1,0,0, ' + ((tiltFB + this.secondRandom) * -1) + 'deg)'
      logo.style.MozTransform = 'rotate(' + (tiltLR + this.firstRandom) + 'deg)'
      logo.style.transform = 'rotate(' + (tiltLR + this.firstRandom) + 'deg) rotate3d(1,0,0, ' + ((tiltFB + this.secondRandom) * -1) + 'deg)'
    }
  }
}
</script>

<style scoped>

.container {
  perspective: 300;
  -webkit-perspective: 300;
}

#imgLogo {
  width: 275px;
  margin-left: auto;
  margin-right: auto;
  display: block;
  padding: 15px;
}

.play__feedback {
  background-color: #ccc;
  width: 80%;
  margin: auto;
  border-radius: 10%;
  box-shadow: 0 0 5;
}
</style>
